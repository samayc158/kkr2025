import numpy as np
import pandas as pd
from sklearn.datasets import load_iris, load_wine
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import BaggingClassifier, AdaBoostClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report

# Load datasets
iris = load_iris()
wine = load_wine()

iris_data = pd.DataFrame(data=iris.data, columns=iris.feature_names)
iris_target = iris.target

wine_data = pd.DataFrame(data=wine.data, columns=wine.feature_names)
wine_target = wine.target

def evaluate_classifiers(X_train, X_test, y_train, y_test, n_estimators_list):
    # Initialize results dictionary
    results = {}
    
    # Single Decision Tree Classifier
    dt_clf = DecisionTreeClassifier()
    dt_clf.fit(X_train, y_train)
    dt_pred = dt_clf.predict(X_test)
    results['Decision Tree'] = accuracy_score(y_test, dt_pred)
    
    # Bagging Ensemble
    for n in n_estimators_list:
        bagging_clf = BaggingClassifier(base_estimator=DecisionTreeClassifier(),
                                        n_estimators=n,
                                        random_state=42)
        bagging_clf.fit(X_train, y_train)
        bagging_pred = bagging_clf.predict(X_test)
        results[f'Bagging ({n} estimators)'] = accuracy_score(y_test, bagging_pred)
    
    # AdaBoost Ensemble
    for n in n_estimators_list:
        adaboost_clf = AdaBoostClassifier(base_estimator=DecisionTreeClassifier(max_depth=1),
                                          n_estimators=n,
                                          random_state=42)
        adaboost_clf.fit(X_train, y_train)
        adaboost_pred = adaboost_clf.predict(X_test)
        results[f'AdaBoost ({n} estimators)'] = accuracy_score(y_test, adaboost_pred)
    
    return results

# Iris Dataset
X_train_iris, X_test_iris, y_train_iris, y_test_iris = train_test_split(iris_data, iris_target, test_size=0.25, random_state=42)
n_estimators_list = [3, 5, 7, 9]

print("Iris Dataset Results:")
iris_results = evaluate_classifiers(X_train_iris, X_test_iris, y_train_iris, y_test_iris, n_estimators_list)
for model, accuracy in iris_results.items():
    print(f"{model}: {accuracy:.4f}")

# Wine Dataset
X_train_wine, X_test_wine, y_train_wine, y_test_wine = train_test_split(wine_data, wine_target, test_size=0.25, random_state=42)

print("\nWine Dataset Results:")
wine_results = evaluate_classifiers(X_train_wine, X_test_wine, y_train_wine, y_test_wine, n_estimators_list)
for model, accuracy in wine_results.items():
    print(f"{model}: {accuracy:.4f}")
