import nltk
import string
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd

# Download necessary NLTK resources (if not already installed)
nltk.download('stopwords')
nltk.download('punkt_tab')

# Sample text document (You can replace this with your own text document)
document = """
Natural language processing (NLP) is a field of computer science, artificial intelligence, and computational linguistics 
concerned with the interactions between computers and human language, and, in particular, concerned with programming 
computers to fruitfully process large natural language data.
"""

# a. Stop Word Removal
stop_words = set(stopwords.words('english'))
words = nltk.word_tokenize(document)
filtered_words = [word for word in words if word.lower() not in stop_words]
print("After removal of stop words : ")
print(*filtered_words)
print()

# b. Stemming
ps = PorterStemmer()
stemmed_words = [ps.stem(word) for word in words]
print("Result of stemming :")
print(*stemmed_words)
print()

# c. Removal of punctuation marks
punctuation_free = [word for word in words if word not in string.punctuation]
print("After removal of punctation marks : ")
print(*punctuation_free)
print()

# d. Compute the Inverse Document Frequency (IDF)

# Here we create a sample corpus with just the one document, you can expand it
corpus = [document]

# Initialize the TF-IDF Vectorizer
tfidf = TfidfVectorizer()

# Fit the model and compute the IDF values
tfidf_matrix = tfidf.fit_transform(corpus)

# Convert IDF values into a readable form (word, idf value)
idf_values = pd.DataFrame(list(zip(tfidf.get_feature_names_out(), tfidf.idf_)), columns=["Word", "IDF"])
idf_values = idf_values.sort_values(by="IDF", ascending=False)

print("\nIDF Values for Words in the Document:")
print(idf_values)

