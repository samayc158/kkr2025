# Import libraries
import numpy as np
import pandas as pd
from sklearn.datasets import fetch_openml
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.covariance import EllipticEnvelope
from sklearn.cluster import DBSCAN
from scipy.stats import zscore
import matplotlib.pyplot as plt
import seaborn as sns

# Load a dataset from OpenML
data = fetch_openml(name="wine", version=1, as_frame=True)
df = data.data
df['target'] = data.target

print("Dataset Loaded:")
print(df.head())

# Select features for outlier detection
features = ["Alcohol", "Malic_acid"]  # Example features
X = df[features]

# Scatter plot to visualize potential outliers
sns.scatterplot(x=X[features[0]], y=X[features[1]])
plt.title("Scatter Plot of Features")
plt.xlabel(features[0])
plt.ylabel(features[1])
plt.show()

# 1. Isolation Forest
iso_forest = IsolationForest(contamination=0.1, random_state=42)
iso_outliers = iso_forest.fit_predict(X)
df['IsoForest_Outlier'] = (iso_outliers == -1)

# 2. Local Outlier Factor (LOF)
lof = LocalOutlierFactor(n_neighbors=30, contamination=0.1)
lof_outliers = lof.fit_predict(X)
df['LOF_Outlier'] = (lof_outliers == -1)

# 3. Elliptic Envelope (Gaussian)
elliptic_env = EllipticEnvelope(contamination=0.1, random_state=42)
elliptic_outliers = elliptic_env.fit_predict(X)
df['Elliptic_Outlier'] = (elliptic_outliers == -1)

# 4. Z-score Method
z_scores = np.abs(zscore(X))
threshold = 3  # Typical threshold for outliers
z_outliers = (z_scores > threshold).any(axis=1)
df['ZScore_Outlier'] = z_outliers

# 5. DBSCAN Outlier Detection
dbscan = DBSCAN(eps=0.5, min_samples=10)  # Tune eps and min_samples based on data
dbscan_labels = dbscan.fit_predict(X)
df['DBSCAN_Outlier'] = (dbscan_labels == -1)  # DBSCAN labels -1 as outliers

# Plot the results for each method
methods = ["IsoForest_Outlier", "LOF_Outlier", "Elliptic_Outlier", "ZScore_Outlier", "DBSCAN_Outlier"]
for method in methods:
    sns.scatterplot(x=X[features[0]], y=X[features[1]], hue=df[method], palette=["blue", "red"])
    plt.title(f"Outlier Detection using {method}")
    plt.xlabel(features[0])
    plt.ylabel(features[1])
    plt.legend(title="Outlier")
    plt.show()

# Compare the number of outliers detected
outlier_counts = df[methods].sum()
print("\nOutlier Counts:")
print(outlier_counts)

# Summary of Outlier Detection Results
print("\nSummary of Outlier Detection Results:")
print(df[methods].mean() * 100)  # Percentage of outliers detected by each method
