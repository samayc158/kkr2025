import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, davies_bouldin_score
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# Load Air Passengers dataset
data_path = "AirPassengers.csv"  # Replace with your dataset path or use the following:
# If unavailable, use statsmodels dataset
# from statsmodels.datasets import get_rdataset
# air_passengers = get_rdataset('AirPassengers', package='datasets').data

# Sample Air Passengers dataset structure
data = pd.read_csv(data_path, parse_dates=['Month'], index_col='Month')

# Preview the dataset
print("Dataset Loaded!")
print(data.head())

# Normalize the data
data = data[['#Passengers']]  # Use "Passengers" as the feature for clustering
scaler = StandardScaler()
normalized_data = scaler.fit_transform(data)

# Simulate CluStream (placeholder: divide data into chunks and use K-means on chunks)
chunk_size = 12  # Chunk by year (12 months per chunk)
micro_clusters = []
for i in range(0, len(normalized_data), chunk_size):
    chunk = normalized_data[i:i+chunk_size]
    if len(chunk) > 1:  # Avoid empty chunks
        kmeans = KMeans(n_clusters=3, random_state=42)
        labels = kmeans.fit_predict(chunk)
        micro_clusters.append(kmeans.cluster_centers_)

# Flatten micro-cluster centers
micro_cluster_centers = np.vstack(micro_clusters)

# Apply K-means to "macro-cluster" the micro-clusters
kmeans_macro = KMeans(n_clusters=3, random_state=42)
macro_labels = kmeans_macro.fit_predict(micro_cluster_centers)

# Evaluate K-means directly on full data for comparison
kmeans_full = KMeans(n_clusters=3, random_state=42)
kmeans_labels = kmeans_full.fit_predict(normalized_data)

# Evaluate CluStream-like method vs K-means
silhouette_clustream = silhouette_score(micro_cluster_centers, macro_labels)
silhouette_kmeans = silhouette_score(normalized_data, kmeans_labels)

db_clustream = davies_bouldin_score(micro_cluster_centers, macro_labels)
db_kmeans = davies_bouldin_score(normalized_data, kmeans_labels)

print("Simulated CluStream Silhouette Score:", silhouette_clustream)
print("K-means Silhouette Score:", silhouette_kmeans)
print("Simulated CluStream Davies-Bouldin Index:", db_clustream)
print("K-means Davies-Bouldin Index:", db_kmeans)

# Visualization
plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.plot(data.index, normalized_data, label='Normalized Data')
plt.scatter(data.index, normalized_data, c=kmeans_labels, cmap='viridis', s=20, label='Clusters')
plt.title("K-means Clustering (Full Data)")
plt.xlabel('Time')
plt.ylabel('Normalized Passengers')
plt.legend()

plt.subplot(1, 2, 2)
plt.scatter(range(len(micro_cluster_centers)), micro_cluster_centers[:, 0], c=macro_labels, cmap='viridis', s=50)
plt.title("Simulated CluStream Clustering")
plt.xlabel('Micro-Cluster Index')
plt.ylabel('Cluster Center (Normalized Passengers)')
plt.show()
