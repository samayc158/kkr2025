# Import libraries
import numpy as np
import pandas as pd
from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt
import seaborn as sns

# Generate a synthetic dataset
X, _ = make_blobs(n_samples=500, n_features=2, centers=4, cluster_std=1.0, random_state=42)
df = pd.DataFrame(X, columns=["Feature1", "Feature2"])

# Visualize the dataset
plt.scatter(df["Feature1"], df["Feature2"], c="blue", s=10)
plt.title("Dataset")
plt.xlabel("Feature1")
plt.ylabel("Feature2")
plt.show()

# 1. Partitioning Clustering (K-Means)
print("\nK-Means Clustering:")
for k in [2, 3, 4, 5]:  # Try different numbers of clusters
    kmeans = KMeans(n_clusters=k, random_state=42)
    labels = kmeans.fit_predict(X)
    score = silhouette_score(X, labels)
    print(f"Number of Clusters: {k}, Silhouette Score: {score:.2f}")

    # Plot the clustering results
    plt.scatter(X[:, 0], X[:, 1], c=labels, cmap="viridis", s=10)
    plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], c="red", marker="X", s=100)
    plt.title(f"K-Means Clustering (k={k})")
    plt.xlabel("Feature1")
    plt.ylabel("Feature2")
    plt.show()

# 2. Hierarchical Clustering (Agglomerative)
print("\nAgglomerative Clustering:")
for k in [2, 3, 4, 5]:  # Try different numbers of clusters
    agg = AgglomerativeClustering(n_clusters=k)
    labels = agg.fit_predict(X)
    score = silhouette_score(X, labels)
    print(f"Number of Clusters: {k}, Silhouette Score: {score:.2f}")

    # Plot the clustering results
    plt.scatter(X[:, 0], X[:, 1], c=labels, cmap="viridis", s=10)
    plt.title(f"Agglomerative Clustering (k={k})")
    plt.xlabel("Feature1")
    plt.ylabel("Feature2")
    plt.show()

# 3. Density-Based Clustering (DBSCAN)
print("\nDBSCAN Clustering:")
for eps in [0.5, 1.0, 1.5]:  # Try different epsilon values
    dbscan = DBSCAN(eps=eps, min_samples=5)
    labels = dbscan.fit_predict(X)
    # Silhouette score only works if there are more than 1 cluster
    if len(set(labels)) > 1:
        score = silhouette_score(X, labels)
        print(f"Epsilon: {eps}, Silhouette Score: {score:.2f}")
    else:
        print(f"Epsilon: {eps}, Silhouette Score: Not Applicable (Only one cluster detected)")

    # Plot the clustering results
    plt.scatter(X[:, 0], X[:, 1], c=labels, cmap="viridis", s=10)
    plt.title(f"DBSCAN Clustering (eps={eps})")
    plt.xlabel("Feature1")
    plt.ylabel("Feature2")
    plt.show()
