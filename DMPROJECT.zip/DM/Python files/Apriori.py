from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules
import pandas as pd


# Create a DataFrame from the dataset
netflix_df = pd.read_csv(r'C:\Users\negis\OneDrive\Desktop\DU\SEM4\Data Mining\DM\file1.csv')

netflix_df['imdb_score'] = netflix_df['imdb_score'].fillna(netflix_df['imdb_score'].mean())
netflix_df['description'] = netflix_df['description'].fillna('Not known')
netflix_df['imdb_votes'] = netflix_df['imdb_votes'].fillna(netflix_df['imdb_votes'].mean())

# Convert numerical attributes to categorical for binning
netflix_df['runtime_bins'] = pd.cut(netflix_df['runtime'], bins=3, labels=['short', 'medium', 'long'])
netflix_df['imdb_score_bins'] = pd.cut(netflix_df['imdb_score'], bins=3, labels=['low', 'medium', 'high'])
netflix_df['release_year_bins'] = pd.cut(netflix_df['release_year'], bins=3, labels=['early', 'mid', 'late'])

# Select relevant attributes for Apriori analysis
attributes = ['type', 'runtime_bins', 'imdb_score_bins', 'release_year_bins']
netflix_apriori = netflix_df[attributes]

# One-hot encode the attributes
netflix_encoded = pd.get_dummies(netflix_apriori)

# Find frequent itemsets using Apriori algorithm
frequent_itemsets = apriori(netflix_encoded, min_support=0.2, use_colnames=True)

# Generate association rules
rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1)

# Display frequent itemsets and association rules
print("Frequent Itemsets:")
print(frequent_itemsets)
print("\nAssociation Rules:")
print(rules)

