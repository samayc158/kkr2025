
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score

# Create a DataFrame from the dataset
netflix_df = pd.read_csv(r'C:\Users\negis\OneDrive\Desktop\DU\SEM4\Data Mining\DM\file1.csv')

netflix_df['imdb_score'] = netflix_df['imdb_score'].fillna(netflix_df['imdb_score'].mean())
netflix_df['description'] = netflix_df['description'].fillna('Not known')
netflix_df['imdb_votes'] = netflix_df['imdb_votes'].fillna(netflix_df['imdb_votes'].mean())

# Map 'Movie' to 0 and 'TV Show' to 1 for target variable
netflix_df['type'] = netflix_df['type'].map({'MOVIE': 0, 'SERIES': 1})

# Define features and target variable
X = netflix_df[['runtime', 'imdb_score', 'release_year']]
y = netflix_df['type']


# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# Initialize the Naive Bayes classifier (Gaussian Naive Bayes for continuous features)
clf = GaussianNB()

# Train the classifier on the training data
clf.fit(X_train, y_train)

# Make predictions on the testing data
y_pred = clf.predict(X_test)

# Evaluate the accuracy of the classifier
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

